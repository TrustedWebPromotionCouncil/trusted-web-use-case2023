import logging
import time

from django.utils import timezone
from django.core.exceptions import ValidationError
from django.shortcuts import get_object_or_404, get_list_or_404
from django.db import transaction

from django.db.models import Max, F, Q, Subquery, OuterRef
from django.db.models.functions import Coalesce



from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.views import APIView
from croTrustedDirectory.settings import CLIENT_ID, CLIENT_SECRET, BOX_USER

from crodirectory.constants import  \
    STATUS_DEFAULT, STATUS_CHOICES, STATUS_BEFORE_CONSENT, STATUS_ON_GOING, STATUS_DISCONTINUATION, STATUS_COMPLETE, \
    ESIGN_STATUS_CONSCENT, IC_TYPE_WITHDRAW_IC

from .models import IcDocument, Participant, StudyHospital, StudyParticipants, StudySubjects, StudySubjectIc, Study,   \
      Hospital,  StudySubjectsStatus, SubjectDeviceStudy, SubjectDevices
from .serializers import ChangeSubjectsStatusSerializer, CreateSubjectDeviceSerializer, \
     ExplainSignSerializer, IcDocumentSerializer, ParticipantSerializer, \
     SubjectDeviceStudySerializer, UpdateParticipantSerializer, \
     MyStudiesSerializer, MyContactsSerializer, StudyParticipantSerializer, SubjectSerializer,  \
     MySubjectContactsSerializer, UpdateSubjectDeviceStudySerializer, UpdateSubjectUriSerializer,  \
     StudySubjectsStatusSerializer, \
     MySubjectStudyHospitalSerializer, CreateStudySubjectIcSerializer, \
     StudySubjectIcSerializer, ParticipantNameSerializer, SubjectIdSerializer, \
     CreateWithdrawIcSerializer, ExplainSignerSerializer

from boxsdk import Client, CCGAuth


class ParticipantView(APIView):
    def get(self, request, participant_id):
        logging.info("views start")
        
        participant = get_object_or_404(Participant, participant_id=participant_id, is_valid=True)
        serializer = ParticipantSerializer(participant)
        return Response(serializer.data)

    def patch(self, request, participant_id):
        participant = get_object_or_404(Participant, participant_id=participant_id, is_valid=True)
        serializer = UpdateParticipantSerializer(data=request.data)

        if serializer.is_valid():
            serializer.update(participant, serializer.validated_data)
            return Response('ok')
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def studies(request, participant_id):
    participant = get_object_or_404(Participant, participant_id=participant_id, is_valid=True)
    serializer = MyStudiesSerializer(participant)
    return Response(serializer.data)


@api_view(['GET'])
def all_studies_by_participant(request):
    query_set = Participant \
        .objects \
        .filter(studyparticipants__isnull=False) \
        .filter(studyparticipants__is_valid=True) \
        .filter(studyparticipants__study_hospital__is_valid=True) \
        .filter(is_valid=True) \
        .distinct()
    serializer = MyStudiesSerializer(query_set, many=True)
    return Response(serializer.data)


class StudyParticipantView(APIView):
    def get(self, request):
        query = StudyParticipants.objects.all()
        serializer = StudyParticipantSerializer(query, many=True)
        return Response(serializer.data)

    def delete(self, request, id):
        participant = get_object_or_404(StudyParticipants, id=id)
        participant.delete(keep_parents=True)
        return Response('ok')
    

@api_view(['GET'])
def contacts(request, participant_id, study_id, hospital_id):
    """
    PC用のコンタクト取得API
    participant_id, study_id, hospital_idをもとにスタディホスピタルを特定し、
    それに含まれる被験者とデバイスのリストを返す
    デバイスは、その被験者のステータスが「同意前」以外＝同意後かつ中止終了までであり、
    試験に紐づけられたデバイスだけを取得する。
    """

    try:
        Participant.objects.get(participant_id=participant_id, is_valid=True)

    except:
        return Response({"message": "participant ID: {} is not exists".format(participant_id)},  status=status.HTTP_400_BAD_REQUEST)

    try:
        study_hospital = StudyHospital.objects.get(study_id=study_id, hospital_id=hospital_id, is_valid=True)

    except:
        return Response({"message": "The studyhospital is not exists"},  status=status.HTTP_400_BAD_REQUEST)
    
    serializer = MyContactsSerializer(study_hospital)
    return Response(serializer.data)

@api_view(['POST'])
def createsubject(request, subject_code, study_id, hospital_id):
    ERROR_MESSAGE = "error_message"

    try: 
        subject = StudySubjects.objects.get(subject_code=subject_code, study__id = study_id)

        if subject.first_access:
            return Response({ERROR_MESSAGE: "Subject with study: {}, code: {} already exists.".format(study_id, subject_code)}) # , status=status.HTTP_400_BAD_REQUEST
        
        else:
            serializer = SubjectSerializer(subject)
            return Response(serializer.data)

    except StudySubjects.DoesNotExist:

        study_hospital = get_object_or_404(StudyHospital, study_id=study_id, hospital_id=hospital_id, is_valid=True)
        study = get_object_or_404(Study, id=study_id, is_valid=True)
        hospital = get_object_or_404(Hospital, id=hospital_id, is_valid=True)

        parent_folder_box_id = study_hospital.box_id
        try:
            box_id_subject = _createboxofsubject(parent_folder_box_id, subject_code)

            try:
                with transaction.atomic(): 
                    new_subject = StudySubjects(study=study, hospital=hospital, subject_code=subject_code, box_id_subject=box_id_subject)
                    new_subject.full_clean()
                    new_subject.save()

                    new_subject_status = StudySubjectsStatus(
                        study_subject=new_subject, 
                        status=STATUS_BEFORE_CONSENT
                        ) 
                    new_subject_status.full_clean()
                    new_subject_status.save()

                    serializer = SubjectSerializer(new_subject)

                return Response(serializer.data)
            except ValidationError as e:
                logging.error(e)
                return Response(e)
            
            except Exception as e:
                logging.error(e)
                return Response({ERROR_MESSAGE:"不明なエラー"})

        
        except Exception as e:
            logging.error(e)
            return Response({ERROR_MESSAGE:'BOX APIでエラーが発生しました。不正なBOX IDが登録されている可能性があります'})


class SubjectView(APIView):
    def get(self, request,studysubjects_id ):
        '''
        PCに対して、被験者データとステータス、およびその被験者の同意履歴を返すAPI
        ・study_subject: StudySubjects、StudySubjectsStatus
        ・study_subject_ic: StudySubjectIc、IcDocumentのテーブルからデータを取得する
          ・esign_signer: esign_statusがEならParticipantインすんタンス、CならStudysubjectインスタンスを返す
        '''
        response_datas = {}

        subject = get_object_or_404(StudySubjects, pk=studysubjects_id)
        subject_data = SubjectSerializer(subject).data

        response_datas['study_subject'] = subject_data


        study_subject_ics = StudySubjectIc.objects.filter(study_subject_id=studysubjects_id).order_by('ic_number', 'ic_number_seq')

        response_ic_datas = []

        if study_subject_ics.exists():
            print("study_subject_ics")

            for study_subject_ic in study_subject_ics:
               ic_with_esigner_data = _get_ic_with_esigner(study_subject_ic = study_subject_ic, need_doc_nm=True)
               response_ic_datas.append(ic_with_esigner_data)
               print(response_ic_datas)

        response_datas["study_subject_ic"] =response_ic_datas

        
        return Response(response_datas)


class IcDocumentView(APIView):
    def get(self, request,study_id, hospital_id ):
        try:
            study_hospital = StudyHospital.objects.get(study_id=study_id, hospital_id=hospital_id, is_valid=True)
            ic_document = IcDocument.objects.filter(study_hospital = study_hospital)
        except:
            return Response({"message": "The studyhospital is not exists"},  status=status.HTTP_400_BAD_REQUEST)
        
        serializer = IcDocumentSerializer(ic_document, many =True)
        return Response(serializer.data)


@api_view(['PATCH'])
def changesubjectstatus(request, studysubjects_id):
    subject_status = get_object_or_404(StudySubjectsStatus, study_subject_id=studysubjects_id)

    if subject_status.status in [STATUS_BEFORE_CONSENT, STATUS_DISCONTINUATION, STATUS_COMPLETE]:
        return Response({"message":"同意前または中止または終了した被験者のステータスは変更できません"}, status=status.HTTP_400_BAD_REQUEST)

    serializer = ChangeSubjectsStatusSerializer(subject_status, data= request.data)

    if serializer.is_valid():
        if serializer.validated_data['status'] in [STATUS_DISCONTINUATION, STATUS_COMPLETE]:
            print("serializer.validated_data['status']: "+serializer.validated_data['status'])
            with transaction.atomic():
                serializer.save()

                sds = SubjectDeviceStudy.objects.filter(study_subject_id=studysubjects_id)
                sds.update(is_valid=False) 

        else:
            serializer.save()

        return Response(serializer.data)
    else:
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SignOfExplainView(APIView):
    def patch(self, request, study_subject_ic_id):
        '''
        施設スタッフによる署名が行われ時にたたくAPI。以下のデータを更新する。
        
        テーブル: StudySubjectIc
        フィールド: 'esign_signer_id', 'esign_date', 'ic_signdoc_nm', 'ic_signdoc_box_id'
        esign_dateは以下Viewsの中で自動で取得する。
        '''
        try:
            study_subject_ic = StudySubjectIc.objects.get(pk = study_subject_ic_id)

            if study_subject_ic.esign_date is not None:
                raise Exception('already signed')

            data=request.data
            data['esign_date'] = timezone.now()

            serializer = ExplainSignSerializer(study_subject_ic, data=data)

            if serializer.is_valid():
                serializer.save()

                return Response({'result':"True"})
            else:
                logging.error(serializer.errors)
                raise Exception(serializer.errors)
        except Exception as e:
            logging.error(str(e))
            return Response({"result": "False"}, status=status.HTTP_400_BAD_REQUEST)

class ExplainSignerView(APIView):
    def post(self, request):
        data=request.data

        try: 
            data['esign_status'] = 'E'
            
            print(data)

            serializer = ExplainSignerSerializer(data=data)

            if serializer.is_valid():
                new_study_subject_ic = serializer.save()
                print(new_study_subject_ic)
                print(new_study_subject_ic.ic_doc)
                new_ic_serializer = _get_ic_with_esigner(study_subject_ic = new_study_subject_ic, need_doc_nm=True)
                print(new_ic_serializer)
                
                return Response(new_ic_serializer)
            else:
                logging.error(str(serializer.errors))

                raise Exception('serializer is not valid')
        except Exception as e:
            logging.error(str(e))
            return Response({})
    
    def delete(self, request, study_subject_ic_id):
        try:
            study_subject_ic = StudySubjectIc.objects.get(pk = study_subject_ic_id)
            if study_subject_ic.esign_date is None:
                study_subject_ic.delete()
                return Response({"result": "True"})
            else:
                raise Exception('already signed')

        except Exception as e:
            logging.error(str(e))
            return Response({"result": "False"}, status=status.HTTP_400_BAD_REQUEST)

    

@api_view(['PATCH'])
def subjectaccept(request, studysubjects_id):
    subject = get_object_or_404(StudySubjects, id=studysubjects_id)

    if subject.first_access:
        subject.accepted = True
        subject.save()

        return Response('ok')
    else:
        logging.error('The subject has not access TD yet.')
        return Response({"message":'The subject has not access TD yet.'}, status=status.HTTP_400_BAD_REQUEST)



@api_view(['PATCH'])
def subjectfirstaccess(request, studysubjects_id):
    try:
        subject = StudySubjects.objects.get(pk=studysubjects_id)
        subject.first_access = True
        subject.save()
        return Response({"result": "True"})
    except:
        return Response({"result": "False"})

class UpdateSubjectUriView(APIView):
    def patch(self, request, studysubjects_id):
        try:            
            subject = StudySubjects.objects.get(pk=studysubjects_id)
            serializer = UpdateSubjectUriSerializer(data=request.data)
            if serializer.is_valid():
                serializer.update(subject, serializer.validated_data)
                return Response({"result": "True"})
            else:
                raise Exception('serializer is not valid')
        except:
            return Response({"result": "False"})

@api_view(['GET'])
def subjectcontacts(request, studysubjects_id):
    try:
        subject = StudySubjects.objects.get(pk=studysubjects_id)
        
        if subject.study_subjects_status.status in [STATUS_BEFORE_CONSENT, STATUS_ON_GOING]:

            serializer = MySubjectContactsSerializer(subject)
            return Response(serializer.data)
        else:
            return Response({})

    except Exception as e:
        logging.error(e)
        return Response({})
    

@api_view(['GET'])
def devicecontacts(request, subject_device_id):
    '''
    deviceがPairingすべきParticipantのリストをstudy_subject_idごとに返す。
    ・subject_device_idをもつstudy_subjectの一覧を取得
    ・各study_subjectとPairingすべきParticipantのデータを取得
    ・Participantのデータをシリアライズする
    ・「subject_device_idとParticipantのセット」のリストをResponseとして返す。
    
    レスポンスデータ
    [
        {
            "participants": [
                {Participantのデータ},
                {同上}
            ],
            "study_subject_id": 1
        },
        {同上}
    ]
    '''

    try:
        # subject_device_idから当該subject_deviceを持つstudy_subjectの一覧を取得する。
        study_subject_ids = SubjectDeviceStudy.objects \
            .filter(subject_device_id = subject_device_id, is_valid=True) \
            .select_related('study_subject') \
            .values_list('study_subject__id', flat=True)
        print(study_subject_ids)
        
        subjects = StudySubjects.objects \
            .filter(pk__in = study_subject_ids) \
            .prefetch_related('study','hospital')
        print(subjects)
        
        if not subjects.exists():
            raise Exception('study_subject is not exists')

        
        response_datas = []
        for subject in subjects:
            res = {}
            res['study_subject_id'] = subject.id
            
            participants = _filter_participants_from_subject(subject)
            
            res['participants'] = ParticipantSerializer(participants, many=True).data

            response_datas.append(res)

        return Response(response_datas)


    except Exception as e:
        logging.error(str(e))
        return Response([])


@api_view(['GET'])
def subjectstudyhospital(request, studysubjects_id):
    try:
        subject = StudySubjects.objects.get(pk=studysubjects_id)
        if subject.accepted == False:
            logging.error("this subject is not accepted yet.")
            raise Exception

        study_hospital = StudyHospital.objects.get(study_id = subject.study_id, hospital_id = subject.hospital_id)

        serializer = MySubjectStudyHospitalSerializer(study_hospital)
        return Response(serializer.data)
    except:
        return Response({})
    

@api_view(['GET'])
def subjecticdoc(request, studysubjects_id):
    
    try:
        subject = StudySubjects.objects.get(pk=studysubjects_id)

        if subject.first_access==True and subject.accepted==True:
            '''
            同一ic_numberのレコードのうち、すべてのesign_dateがNULLでないとき、そのレコードの中で最もesign_dateが新しいものを返す。
            （同一ic_numberのレコードのうち、一つでもesign_dateがNULLである場合、そのic_numberのレコードは返さない）
            '''                      
            
            latest_ic = None

            subject_ics = StudySubjectIc.objects.filter(study_subject=subject)

            withdraw_ic = subject_ics.filter(ic_type = IC_TYPE_WITHDRAW_IC).first()

            if withdraw_ic:
                latest_ic = withdraw_ic

            else:
            # WIのレコードがない場合
                not_signed_ic_num = subject_ics.filter(esign_date__isnull = True).values_list('ic_number', flat=True)
                signed_subject_ics = subject_ics.exclude(ic_number__in = not_signed_ic_num)
                latest_ic = signed_subject_ics.order_by('-ic_number', '-esign_date').first()

            if latest_ic:
                print(latest_ic)
                response_data = _get_ic_with_esigner(study_subject_ic = latest_ic, need_doc_nm=False)
            
                response_data["box_id_subject"] = subject.box_id_subject

                return Response(response_data)
            else:
                raise Exception('iclogs are not exists or the first explaining is not completed')
        else:
            raise Exception('serializer is not valid or first_access = false or accepted == false')
    
    except Exception as e:
        logging.error(str(e))
        return Response({})

    

class CreateStudySubjectIcView(APIView):
    def post(self, request):
        try:
            serializer = CreateStudySubjectIcSerializer(data=request.data, partial=True)

            if serializer.is_valid():
                with transaction.atomic(): 
                    new_ic = serializer.create(serializer.validated_data)
                    subject_status = StudySubjectsStatus.objects.get(study_subject = new_ic.study_subject)

                    subject_status.status = STATUS_ON_GOING
                    subject_status.save()

                return Response({'result':"True"})
            else:
                logging.error(str(serializer.errors))
                raise Exception('serializer is not valid')

        except Exception as e:
            logging.error(str(e))
            return Response({"result": "False"})


class CreateWithdrawIc(APIView):
    def post(self, request):
        try:
            serializer = CreateWithdrawIcSerializer(data=request.data, partial=True)

            if serializer.is_valid():
                validated_data = serializer.validated_data
                serializer.create(validated_data)
                
                return Response({'result':"True"})
            else:
                logging.error(str(serializer.errors))
                raise Exception('serializer is not valid')
        except Exception as e:
            logging.error(str(e))
            return Response({"result": "False"})


@api_view(['GET'])
def aftericdoc(request, studysubjects_id):
    
    errormsg = ""
    try:

        study_subject_ics = StudySubjectIc.objects.filter( \
            study_subject_id=studysubjects_id, \
            esign_status='C')

        if study_subject_ics.exists():

            response_datas = []

            for study_subject_ic in study_subject_ics:
                response_data = None

                esign_status = study_subject_ic.esign_status
                esign_signer_id = study_subject_ic.esign_signer_id

                if esign_status == 'E':
                    try:
                        participant = Participant.objects.get(pk=esign_signer_id)
                        esign_signer_data = ParticipantNameSerializer(participant).data
                    except Participant.DoesNotExist:
                        errormsg = 'participant are not exist'
                        raise Exception(errormsg)
                    
                elif esign_status == 'C':
                    try:
                        study_subject = StudySubjects.objects.get(pk=esign_signer_id)
                        esign_signer_data = SubjectIdSerializer(study_subject).data
                    except StudySubjects.DoesNotExist:
                        errormsg = 'StudySubjects are not exist'
                        raise Exception(errormsg)
                else:
                    esign_signer_data = None

                response_data = StudySubjectIcSerializer(study_subject_ic).data

                response_data['esign_signer'] = esign_signer_data
                response_datas.append(response_data)

            return Response(response_datas, status=status.HTTP_200_OK)
        else:
            errormsg = 'study_subject_ics are not exist'
            raise Exception(errormsg)
        
    except:
        logging.error(str(errormsg))
        return Response({})
    
@api_view(['GET'])
def iclogs(request, studysubjects_id):

    errormsg = ""
    try:

        study_subject_ics = StudySubjectIc.objects.filter(study_subject_id=studysubjects_id).order_by('ic_number', 'ic_number_seq')

        if study_subject_ics.exists():

            response_datas = []

            for study_subject_ic in study_subject_ics:
                response_data = None

                # esign_statusの値によってesign_signer_dataにParticipantかstudy_subjectかのどちらかのidとNameを格納する。
                esign_status = study_subject_ic.esign_status
                esign_signer_id = study_subject_ic.esign_signer_id
                esign_signer_data = None
                if esign_status == 'E':
                    try:
                        participant = Participant.objects.get(pk=esign_signer_id)
                        esign_signer_data = ParticipantNameSerializer(participant).data
                    except Participant.DoesNotExist:
                        errormsg = 'participant are not exist'
                        raise Exception(errormsg)
                    
                elif esign_status == 'C':
                    try:
                        study_subject = StudySubjects.objects.get(pk=esign_signer_id)
                        esign_signer_data = SubjectIdSerializer(study_subject).data
                    except StudySubjects.DoesNotExist:
                        errormsg = 'StudySubjects are not exist'
                        raise Exception(errormsg)
                else:
                    esign_signer_data = None

                response_data = StudySubjectIcSerializer(study_subject_ic).data
                
                response_data['esign_signer'] = esign_signer_data

                response_data['ic_number-ic_number_seq'] =  \
                    str(response_data['ic_number']) + "-" + str(response_data['ic_number_seq'])

                response_datas.append(response_data)

            return Response(response_datas, status=status.HTTP_200_OK)
        else:
            errormsg = 'study_subject_ics are not exist'
            raise Exception(errormsg)
        
    except:
        logging.error(str(errormsg))
        return Response({})


class StudySubjectsStatusView(APIView):
    def get(self, request, studysubjects_id):
   
        try:
            subject_status = StudySubjectsStatus.objects.get(study_subject_id=studysubjects_id)
            serializer = StudySubjectsStatusSerializer(subject_status)
            return Response(serializer.data)
        except:
            return Response({})


class SubjectDeviceView(APIView):
    def post(self, request):

        data=request.data

        try: 
            study_subject_id = data.get('study_subject_id', None)

            if StudySubjects.objects.get(pk = study_subject_id).study_subjects_status.status != 'O':
                raise Exception("status is not on-going")
            
            device = SubjectDevices()
            device_study = SubjectDeviceStudy()

            with transaction.atomic(): 

                subject_device_id = data.get('subject_device_id', None)
                

                if subject_device_id is None or len(subject_device_id)==0:
                    logging.info('device is not exists')

                    device_serializer = CreateSubjectDeviceSerializer(data=data)
                    print(device_serializer)
                    if device_serializer.is_valid():
                        print("device valid")
                        device = device_serializer.save()
                        subject_device_id = device.id
                    else:
                        logging.error(str(device_serializer.errors))
                        raise

                else:
                    device = SubjectDevices.objects.get_by_pk(subject_device_id)
                    if device:
                        pass
                    else:
                        raise Exception('subject device id is not valid')
                
                device_study = SubjectDeviceStudy.objects.get_by_subject_id_and_device_id(
                    study_subject_id=study_subject_id, 
                    subject_device_id=subject_device_id)
                
                device_study_serializer = None
                if device_study:
                    device_study_serializer = UpdateSubjectDeviceStudySerializer(device_study, data=data)

                else:
                    data['subject_device_id'] = subject_device_id
                    device_study_serializer = SubjectDeviceStudySerializer(data=data)
                print(device_study_serializer)


                if device_study_serializer.is_valid():
                    device_study = device_study_serializer.save()
                    is_valid  = device_study.is_valid
                    
                else:
                    logging.error(str(device_study_serializer.errors))
                    raise

                return Response({"id": subject_device_id,"study_subject_id":study_subject_id, "is_valid": is_valid })


        except Exception as e:
            logging.error(str(e))
            return Response({})



class SubjectDeviceStudyView(APIView):
    
    def get(self, request, studysubjects_id):
        try:
            subject_device_study = SubjectDeviceStudy.objects.filter(study_subject_id=studysubjects_id)
            serializer = SubjectDeviceStudySerializer(subject_device_study, many = True)
            return Response(serializer.data) 
        except:
            return Response({}) 
        

def _createboxofsubject(parent_folder_box_id, subject_code):  
    auth = CCGAuth(
        client_id=CLIENT_ID,
        client_secret=CLIENT_SECRET,
        user=BOX_USER,
        )
            
    client = Client(auth)
    print(f'Id of the authenticated user is: {client.user().get().id}')

    parent_folder_box_id = parent_folder_box_id
    subject_code= subject_code

    subject_folder_box = client.folder(parent_folder_box_id).create_subfolder(subject_code)
    subject_box_id = subject_folder_box.id
    
    print(f'Id of the subject box id is: {subject_folder_box.id}, name: {subject_folder_box.name}')

    return subject_box_id

def _get_ic_with_esigner(study_subject_ic: StudySubjectIc, need_doc_nm: bool):
    ic_with_esigner = StudySubjectIcSerializer(study_subject_ic).data

    esign_status = study_subject_ic.esign_status
    esign_signer_id = study_subject_ic.esign_signer_id

    if esign_status == 'E':
        try:
            participant = Participant.objects.get(pk=esign_signer_id)
            esign_signer_data = ParticipantNameSerializer(participant).data
        except Participant.DoesNotExist:
            errormsg = 'participant are not exist'
            raise Exception(errormsg)
        
    elif esign_status == 'C':
        try:
            study_subject = StudySubjects.objects.get(pk=esign_signer_id)
            esign_signer_data = SubjectIdSerializer(study_subject).data
        except StudySubjects.DoesNotExist:
            errormsg = 'StudySubjects are not exist'
            raise Exception(errormsg)
    else:
        esign_signer_data = None
    
    ic_with_esigner['esign_signer'] = esign_signer_data

    if need_doc_nm:
        ic_doc_data = IcDocumentSerializer(study_subject_ic.ic_doc).data
    
        ic_with_esigner['ic_doc'] = ic_doc_data
    

    return ic_with_esigner

def _filter_participants_from_subject(subject: StudySubjects): 
    participant_ids = StudyHospital.objects.filter(study = subject.study.id, \
                                                hospital_id = subject.hospital.id) \
                                    .prefetch_related('study_participants') \
                                    .values_list('study_participants__participant__id', flat=True)
                
    participants = Participant.objects.filter(id__in = participant_ids, \
                                                is_valid=True)
    
    return participants