from datetime import timezone
import random
import string
from typing import Optional

from django.db import models
from django.utils.crypto import get_random_string

from crodirectory.constants import STATUS_CHOICES, STATUS_DEFAULT, SUBJECT_ROLE_SUBJECT, SUBJECT_ROLE_CHOICES, \
                                    IC_TYPE_IC, IC_TYPE_RE_IC, IC_TYPE_WITHDRAW_IC, IC_TYPE_CHOICES, IC_TYPE_DEFAULT, \
                                    ESIGN_STATUS_CONSCENT, ESIGN_STATUS_EXPLAIN, ESIGN_STATUS_CHOICES, ESIGN_STATUS_DEFAULT  



class Hospital(models.Model):
    name = models.CharField(max_length=255)
    address = models.CharField(max_length=255, null=True, blank=True)
    description = models.TextField(max_length=2000, null=True, blank=True)
    dcf_code = models.CharField(max_length=100, unique=True, null=True, default='')
    is_valid = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=['name']),
            models.Index(fields=['dcf_code']),
        ]
        ordering = ['name']

    def __str__(self):
        return self.name


class Participant(models.Model):
    ROLE_CRO = 'C'
    ROLE_STAFF = 'S'
    ROLE_DEFAULT = ROLE_STAFF

    ROLE_CHOICES = [
        (ROLE_STAFF, 'Hospital Staff'),
        (ROLE_CRO, 'Pharma or CRO'),
    ]

    participant_id = models.CharField(max_length=8, unique=True, null=True, editable=False)
    name = models.CharField(max_length=255)
    sub_name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    uri = models.CharField(max_length=255, null=True, blank=True, editable=False)
    role = models.CharField(max_length=1, choices=ROLE_CHOICES, default=ROLE_DEFAULT)
    description = models.TextField(null=True, blank=True)
    is_valid = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=['participant_id']),
            models.Index(fields=['name', 'sub_name']),
            models.Index(fields=['email']),
            models.Index(fields=['uri']),
        ]

        ordering = ['name', 'sub_name']

        constraints = [
            models.UniqueConstraint(
                fields=["name", "sub_name"],
                name="unique_name_sub_name"
            )
        ]

    def save(self, *args, **kwargs):
        if not self.participant_id or len(self.participant_id) == 0:
            alpha_numeric = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789'
            self.participant_id = get_random_string(6, alpha_numeric)

        super(Participant, self).save(*args, **kwargs)

    def __str__(self):
        if self.sub_name is None:
            return self.name

        return self.name + ' ' + self.sub_name


class Study(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    is_valid = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=['name']),
        ]
        ordering = ['name']

    def __str__(self):
        return self.name


class StudyHospital(models.Model):
    study = models.ForeignKey(Study, on_delete=models.PROTECT)  
    hospital = models.ForeignKey(Hospital, on_delete=models.PROTECT)
    box_id = models.CharField(max_length=100)  
    description = models.TextField(max_length=2000, null=True, blank=True)
    is_valid = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=['box_id']),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=["study", "hospital"],
                name="unique_study_hospital"
            )
        ]

    def __str__(self):
        return self.study.name + ' - ' + self.hospital.name


class StudyParticipants(models.Model):
    study_hospital = models.ForeignKey(StudyHospital, on_delete=models.PROTECT, related_name='study_participants')
    participant = models.ForeignKey(Participant, on_delete=models.PROTECT,  related_name='study_participants')
    description = models.TextField(max_length=2000,null=True, blank=True)
    is_valid = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    @property  # 社内用：@propertyの真下に書く関数はpython のゲッター
    def study(self):
        sh = StudyHospital.objects.filter(id=self.study_hospital_id).first()

        if sh is None:
            pass
        else:
            return sh.study.name

        return ''

    @property
    def hospital(self):
        sh = StudyHospital.objects.filter(id=self.study_hospital_id).first()

        if sh is None:
            pass
        else:
            return sh.hospital.name

        return ''

    @property
    def role(self):
        p = Participant.objects.filter(id=self.participant.id).first()

        if p is None:
            pass
        else:
            for r in p.ROLE_CHOICES:
                if r[0] == p.role:
                    return r[1]

        return ''

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["study_hospital", "participant"],
                name="unique_study_hospital_participant"
            )
        ]

    def __str__(self):
        return self.study_hospital.study.name + ' - ' + self.study_hospital.hospital.name

class StudySubjectQuerySet(models.QuerySet):
    def get_by_pk(self, study_subject_id) -> Optional["StudySubjects"]:
        try:
            return self.get(pk=study_subject_id)
        except StudySubjects.DoesNotExist as e:
            return None


class StudySubjects(models.Model):  

    subject_code = models.CharField(default="default-subject-code", max_length=30)  
    study = models.ForeignKey(Study, on_delete=models.PROTECT, related_name='study')  
    hospital = models.ForeignKey(Hospital, on_delete=models.PROTECT, related_name='hospital')
    role = models.CharField(max_length=1, choices=SUBJECT_ROLE_CHOICES, default=SUBJECT_ROLE_SUBJECT) 
    uri = models.CharField(max_length=255, null=True, blank=True, editable=False)
    box_id_subject = models.CharField(max_length=100)
    first_access = models.BooleanField(default=False)
    accepted = models.BooleanField(default=False)
    description = models.TextField(null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=['subject_code']),
            models.Index(fields=['uri']),
        ]

        ordering = ['subject_code', 'study']

        constraints = [
            models.UniqueConstraint(
                fields=["subject_code", "study"],
                name="unique_subject_code_study"
            )
        ]  

    def __str__(self):
        return self.study.name + '_' + self.subject_code
    
    objects: StudySubjectQuerySet = StudySubjectQuerySet.as_manager()


class StudySubjectsStatus(models.Model):
    study_subject = models.OneToOneField(StudySubjects, on_delete=models.PROTECT, related_name='study_subjects_status')
    status = models.CharField(max_length=1, choices=STATUS_CHOICES, default=STATUS_DEFAULT)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.study_subject.subject_code

class IcDocument(models.Model):
    study_hospital = models.ForeignKey(StudyHospital, on_delete=models.PROTECT)
    ic_doc_seq = models.SmallIntegerField()
    ic_doc_name = models.CharField(max_length=200)
    ic_doc_box_id = models.CharField(max_length=100)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    @property  
    def study(self):
        sh = StudyHospital.objects.filter(id=self.study_hospital_id).first()

        if sh is None:
            pass
        else:
            return sh.study.name

        return ''

    @property
    def hospital(self):
        sh = StudyHospital.objects.filter(id=self.study_hospital_id).first()

        if sh is None:
            pass
        else:
            return sh.hospital.name

        return ''

    def __str__(self):
        return self.study + '_' + self.hospital + '_' +  self.ic_doc_name




class StudySubjectIc(models.Model):
    study_subject = models.ForeignKey(StudySubjects, on_delete=models.PROTECT, related_name='studysubjectic')
    ic_number = models.SmallIntegerField()
    ic_number_seq = models.SmallIntegerField()
    ic_type = models.CharField(max_length=2, choices=IC_TYPE_CHOICES, default=IC_TYPE_DEFAULT)
    ic_doc = models.ForeignKey(IcDocument, on_delete=models.PROTECT, null=True, blank=True)
    esign_status = models.CharField(max_length=2, choices=ESIGN_STATUS_CHOICES, null=True, blank=True)
    esign_signer_id = models.IntegerField(null=True, blank=True)
    esign_date = models.DateTimeField(null=True, blank=True) 
    ic_signdoc_nm = models.CharField(max_length=50, null=True, blank=True)
    ic_signdoc_box_id = models.CharField(max_length=100, null=True, blank=True)
    withdraw_reason = models.TextField(max_length=2000, null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.study_subject.study.name + '_' + self.study_subject.subject_code + '_' + str(self.ic_number) + '-' + str(self.ic_number_seq)
    

# SubjectDevicesモデルに対してget_by_pk()を定義する。 該当するレコードがない場合はエラーの代わりにNoneを返す。
class SubjectDeviceQuerySet(models.QuerySet):
    def get_by_pk(self, subject_device_id) -> Optional["SubjectDevices"]:
        try:
            return self.get(pk=subject_device_id)
        except SubjectDevices.DoesNotExist:
            return None
        

class SubjectDevices(models.Model):
    sequence_id = models.IntegerField()
    device_master_id = models.IntegerField(null=True, blank=True) 
    device_uri = models.CharField(max_length=255, editable=False, null=True, blank=True) 
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return str(self.id)
    
    # 上記で定義したget_by_pk()をSubjectDevicesクラスに紐づける。
    objects: SubjectDeviceQuerySet = SubjectDeviceQuerySet.as_manager()


class SubjectDeviceStudyQuerySet(models.QuerySet):
    def get_by_subject_id_and_device_id(self, study_subject_id: int, subject_device_id: int) -> Optional["StudySubjects"]:
        try:
            return self.get(study_subject_id=study_subject_id, subject_device_id=subject_device_id)
        except SubjectDeviceStudy.DoesNotExist:
            return None

class SubjectDeviceStudy(models.Model):
    study_subject = models.ForeignKey(StudySubjects, on_delete=models.PROTECT, related_name='subject_device_study')
    subject_device = models.ForeignKey(SubjectDevices, on_delete=models.PROTECT, related_name='subject_device_study')  
    is_valid = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["study_subject", "subject_device"],
                name="unique_studysubject_subjectdeviceid"
            )
        ] 

    def __str__(self):
        return self.study_subject.subject_code + '_' + str(self.subject_device.id)
    
    objects: SubjectDeviceStudyQuerySet = SubjectDeviceStudyQuerySet.as_manager()
    

