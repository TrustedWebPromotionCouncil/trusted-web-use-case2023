import logging

from django.utils import timezone
from rest_framework import serializers
from rest_framework.validators import UniqueTogetherValidator

from .models import Participant, StudyParticipants, Study, StudyHospital, Hospital, StudySubjects, StudySubjectIc,  StudySubjectsStatus, IcDocument, SubjectDevices, SubjectDeviceStudy

from crodirectory.constants import ESIGN_STATUS_CONSCENT, IC_TYPE_IC, IC_TYPE_WITHDRAW_IC, STATUS_CHOICES, STATUS_DISCONTINUATION, STATUS_COMPLETE, STATUS_ON_GOING, STATUS_BEFORE_CONSENT, \
                                    IC_TYPE_CHOICES

class ParticipantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Participant
        fields = ['id', 'participant_id', \
                  'name', 'sub_name', \
                  'email', 'uri', 'role', \
                  'created', 'updated']


class UpdateParticipantSerializer(serializers.ModelSerializer):
    uri = serializers.CharField(max_length=255, allow_blank=False, allow_null=False)

    class Meta:
        model = Participant
        fields = ['uri']

    def update(self, instance, validated_data):
        instance.uri = validated_data.get('uri')
        instance.save()
        return instance


class HospitalSerializer(serializers.ModelSerializer):
    class Meta:
        model = Hospital
        fields = ['id', 'name', 'description', 'created', 'updated']


class StudySerializer(serializers.ModelSerializer):
    class Meta:
        model = Study
        fields = ['id', 'name', 'description', 'created', 'updated']


class StudyHospitalSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    hospital_id = serializers.IntegerField()
    box_id = serializers.CharField(max_length=255)
    dcf_code = serializers.CharField(max_length=255)
    created = serializers.DateTimeField()
    updated = serializers.DateTimeField()


class StudyParticipantSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudyParticipants
        fields = ['id', 'study_hospital_id', 'participant_id', 'is_valid', 'created', 'updated']


class MyStudiesSerializer(serializers.Serializer):
    participant_id = serializers.CharField(max_length=8)
    study_hospitals = serializers.SerializerMethodField(method_name='get_studies')

    def get_studies(self, participant: Participant):
        study_participants = StudyParticipants \
            .objects \
            .filter(participant_id=participant.id) \
            .filter(is_valid=True) \
            .values_list('study_hospital_id', flat=True)

        study_hospital = StudyHospital \
            .objects \
            .filter(pk__in=study_participants) \
            .values('id',
                    'box_id',
                    'created',
                    'updated',
                    'study_id',
                    'study__name',
                    'study__description',
                    'study__created',
                    'study__updated',
                    'hospital_id',
                    'hospital__name',
                    'hospital__dcf_code',
                    'hospital__description',
                    'hospital__created',
                    'hospital__updated')

        return study_hospital

class UpdateParticipantSerializer(serializers.ModelSerializer):
    uri = serializers.CharField(max_length=255, allow_blank=False, allow_null=False)

    class Meta:
        model = Participant
        fields = ['uri']

    def update(self, instance, validated_data):
        instance.uri = validated_data.get('uri')
        instance.save()
        return instance


class MyContactsSerializer(serializers.Serializer):
    participants = serializers.SerializerMethodField(method_name='get_participants')
    subjects = serializers.SerializerMethodField(method_name='get_subjects')
    devices = serializers.SerializerMethodField(method_name='get_devices')

    def get_participants(self, study_hospital: StudyHospital):
        study_participants = StudyParticipants \
            .objects \
            .filter(is_valid=True) \
            .filter(study_hospital_id=study_hospital.id) \
            .filter(study_hospital__is_valid=True) \
            .filter(study_hospital__study__is_valid=True) \
            .filter(participant__is_valid=True) \
            .values_list('participant_id', flat=True)

        participants = Participant \
            .objects \
            .filter(pk__in=study_participants) \
            .values('id',
                    'participant_id',
                    'name',
                    'sub_name',
                    'role',
                    'uri')
        
        return participants

    def get_subjects(self, study_hospital: StudyHospital):

        study_subjects = StudySubjects \
            .objects \
            .filter(study_id=study_hospital.study.id) \
            .filter(hospital_id=study_hospital.hospital.id) \
            .filter(study__is_valid=True) \
            .filter(hospital__is_valid=True) \
            .values('id',
                    'study',
                    'hospital',
                    'subject_code',
                    'role',
                    'uri',
                    'first_access',
                    'accepted',
                    )

        for subject in study_subjects:
            subject_statuss = StudySubjectsStatus.objects.select_related('study_subject') \
                .get(study_subject_id= subject['id'])

            status = subject_statuss.status
            subject['status'] = status
            subject['status_label'] = subject_statuss.get_status_display()
            print(subject['status_label'] )


            if status in [STATUS_COMPLETE, STATUS_DISCONTINUATION]:
                subject['end_date'] = subject_statuss.updated
            else:
                subject['end_date']=""

            subject_ics = StudySubjectIc.objects.select_related('study_subject') \
                .filter(study_subject_id= subject['id'])
            
            first_ic =  subject_ics.filter(ic_type = IC_TYPE_IC, esign_status=ESIGN_STATUS_CONSCENT)
            if first_ic.exists():
                subject['first_ic_date'] = first_ic.order_by('esign_date').first().esign_date
            else:
                subject['first_ic_date']  = ""
            
            withdraw_ic = subject_ics.filter(ic_type = IC_TYPE_WITHDRAW_IC)
            if withdraw_ic.exists():
                subject['withdraw_ic_date'] =  withdraw_ic.order_by('-created').first().created
            else:
                subject['withdraw_ic_date'] = ""             
       

        return study_subjects


    def get_devices(self, study_hospital: StudyHospital):
        study_subjects = StudySubjects \
            .objects \
            .filter(study_id=study_hospital.study.id) \
            .filter(hospital_id=study_hospital.hospital.id) \
            .filter(study__is_valid=True) \
            .filter(hospital__is_valid=True) \
            .filter(study_subjects_status__status__in = [STATUS_DISCONTINUATION, STATUS_COMPLETE, STATUS_ON_GOING]) \
            .filter(first_access=True) \
            .filter(accepted=True) \
            .values_list('id', flat=True)

        subject_device_study = SubjectDeviceStudy \
            .objects \
            .filter(study_subject_id__in = study_subjects, is_valid= True) \
            .values_list('subject_device_id', flat=True)

        subject_devices = SubjectDevices \
            .objects \
            .filter(pk__in=subject_device_study) \
            .values('id',
                    'sequence_id',
                    'device_master_id',
                    'device_uri'
                    )

        return subject_devices



class SubjectSerializer(serializers.ModelSerializer):
    status = serializers.SerializerMethodField(method_name='get_status')

    def get_status(self, study_subject: StudySubjects):
        if hasattr(study_subject, 'study_subjects_status'):
            return study_subject.study_subjects_status.status
        else:
            return ''

    class Meta:
        model = StudySubjects
        fields = ['id', 'study', 'hospital', 'subject_code','role' ,'uri','box_id_subject', 'description','created', 'updated', 'status']


class ChangeSubjectsStatusSerializer(serializers.ModelSerializer):
    status = serializers.ChoiceField(choices=STATUS_CHOICES)

    def validate_status(self, value):
        if value not in [STATUS_DISCONTINUATION, STATUS_COMPLETE]:
            raise serializers.ValidationError('statusは中止または完了へのみ変更可能です。')
        return value

    class Meta:
        model = StudySubjectsStatus
        fields = ['status']


class ExplainSignSerializer(serializers.ModelSerializer):

    class Meta:
        model = StudySubjectIc
        fields = ['esign_signer_id', 'esign_date', 'ic_signdoc_nm', 'ic_signdoc_box_id']
        
    
class ExplainSignerSerializer(serializers.ModelSerializer):
    study_subject_id = serializers.PrimaryKeyRelatedField(queryset=StudySubjects.objects.all(), \
                                                            write_only=True, \
                                                            source = "study_subject")
    ic_doc_id = serializers.PrimaryKeyRelatedField(queryset=IcDocument.objects.all(), \
                                                    write_only=True, \
                                                    source = "ic_doc")

    class Meta:
        model = StudySubjectIc
        fields = [ 'id', 'ic_number', 'ic_number_seq', 'ic_type', \
                'esign_status', 'esign_signer_id', 'esign_date', \
                'study_subject_id', 'ic_doc_id'] 



class UpdateSubjectUriSerializer(serializers.ModelSerializer):
    uri = serializers.CharField(max_length=255, allow_blank=False, allow_null=False)

    class Meta:
        model = StudySubjects
        fields = ['uri']


class MySubjectContactsSerializer(serializers.Serializer):
    participants = serializers.SerializerMethodField(method_name='get_participants')
    subject_devices = serializers.SerializerMethodField(method_name='get_devices')

    def get_participants(self, study_subject: StudySubjects):
        study_hospital = StudyHospital \
            .objects \
            .get(study_id = study_subject.study, hospital_id = study_subject.hospital)

        study_participants = StudyParticipants \
            .objects \
            .filter(is_valid=True) \
            .filter(study_hospital_id=study_hospital.id) \
            .filter(study_hospital__is_valid=True) \
            .filter(study_hospital__study__is_valid=True) \
            .filter(participant__is_valid=True) \
            .values_list('participant_id', flat=True)

        participants = Participant \
            .objects \
            .filter(pk__in=study_participants) \
            .values('id',
                    'name',
                    'sub_name',
                    'role',
                    'uri')
        
        return participants


    def get_devices(self, study_subject: StudySubjects):
        subject_device_study = SubjectDeviceStudy \
            .objects \
            .filter(study_subject_id = study_subject.id, is_valid= True) \
            .values_list('subject_device_id', flat=True)

        subject_devices = SubjectDevices \
            .objects \
            .filter(pk__in=subject_device_study) \
            .values('id',
                    'sequence_id',
                    'device_master_id',
                    'device_uri'
                    )
        return subject_devices

class DeviceContactsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Participant
        fields = ['uri']


class MySubjectStudyHospitalSerializer(serializers.ModelSerializer):
    study_hospital_name = serializers.SerializerMethodField(method_name='get_study_hospital_name')

    def get_study_hospital_name(self, study_hospital: StudyHospital):
        return '{}-{}'.format(study_hospital.study.name, study_hospital.hospital.name)

    class Meta:
        model = StudyHospital
        fields = ['id', 'study_hospital_name']


class CreateStudySubjectIcSerializer(serializers.ModelSerializer):
    study_subjects_id = serializers.PrimaryKeyRelatedField(queryset=StudySubjects.objects.all(), write_only=True)
    ic_doc_id = serializers.PrimaryKeyRelatedField(queryset=IcDocument.objects.all(), write_only=True)

    class Meta:
        model = StudySubjectIc
        fields = ['study_subject', 'ic_number',  'ic_type', 'ic_doc', \
                  'esign_status', 'esign_signer_id', 'esign_date', 'ic_signdoc_nm', 'ic_signdoc_box_id', \
                  'study_subjects_id', 'ic_doc_id'] # 'ic_number_seq',
        
    def create(self, validated_data):
        validated_data['study_subject'] = validated_data.get('study_subjects_id', None)
        validated_data['ic_doc'] = validated_data.get('ic_doc_id', None)

        if validated_data['study_subject'] is None:
            raise serializers.ValidationError("study_subject not found.") 
        
        if validated_data['ic_doc'] is None:
            raise serializers.ValidationError("ic_doc not found.") 
        
        validated_data['esign_signer_id'] = validated_data['study_subject'].id
        validated_data['esign_status'] = 'C'
        validated_data['esign_date'] = timezone.now()

        last_ic = StudySubjectIc.objects.filter(study_subject = validated_data['study_subject'], \
                                      ic_number = validated_data['ic_number']) \
                                .order_by('-ic_number_seq') \
                                .first() 
        if last_ic:
            validated_data['ic_number_seq'] = last_ic.ic_number_seq + 1
        else:
            raise serializers.ValidationError("the last StudySubjectIc is not found. The doccument was not explained.") 
    
        del validated_data['study_subjects_id']
        del validated_data['ic_doc_id']

        return StudySubjectIc.objects.create(**validated_data)

class CreateWithdrawIcSerializer(serializers.ModelSerializer):
    study_subjects_id = serializers.PrimaryKeyRelatedField(queryset=StudySubjects.objects.all(), write_only=True)
    
    class Meta:
        model = StudySubjectIc
        fields = ['study_subject', 'ic_number', 'ic_number_seq', 'ic_type',  \
                  'study_subjects_id', 'withdraw_reason']
        
    def create(self, validated_data):
        
        validated_data['study_subject'] = validated_data.get('study_subjects_id', None)

        if validated_data['study_subject'] is None:
            raise serializers.ValidationError("study_subject not found.") 
        
        if validated_data['ic_type'] != 'WI':
            raise serializers.ValidationError("ic_type is not WI.") 
        
        latest_Ic = StudySubjectIc.objects.filter( \
            study_subject = validated_data['study_subject']) \
                .order_by('-ic_number', '-ic_number_seq') \
                .first()
        
        validated_data['ic_number'] = latest_Ic.ic_number + 1
        validated_data['ic_number_seq'] = 1

        del validated_data['study_subjects_id']

        return StudySubjectIc.objects.create(**validated_data)

class IcDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = IcDocument
        fields = ['id', 'study_hospital_id', 'ic_doc_seq', 'ic_doc_name', 'ic_doc_box_id']


class ParticipantNameSerializer(serializers.ModelSerializer): 
    '''
    ParticipantのIdとNameを返すシリアライザ
    '''
    class Meta:
        model = Participant
        fields = ['id', 'name']

class SubjectIdSerializer(serializers.ModelSerializer):    
    '''
    StudysubjectのIdとName=""を返すシリアライザ
    '''
    name = serializers.SerializerMethodField(method_name='get_name')

    def get_name(self, instance):
        name = ""
        return name
    
    class Meta:
        model = StudySubjects
        fields = ['id', 'name']

class StudySubjectIcSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudySubjectIc
        fields = '__all__'


###-----------


class StudySubjectsStatusSerializer(serializers.ModelSerializer):  
    class Meta:
        model = StudySubjectsStatus
        fields = [ 'status']

class CreateSubjectDeviceSerializer(serializers.ModelSerializer):
    device_uri = serializers.CharField(max_length=255, allow_blank=True, allow_null=True)

    class Meta:
        model = SubjectDevices
        fields = ['id', 'sequence_id', 'device_master_id', 'device_uri' ]

class SubjectDeviceStudySerializer(serializers.ModelSerializer):
    study_subject_id = serializers.PrimaryKeyRelatedField(queryset=StudySubjects.objects.all(), source='study_subject')
    subject_device_id = serializers.PrimaryKeyRelatedField(queryset=SubjectDevices.objects.all(), source='subject_device')

    class Meta:
        model = SubjectDeviceStudy
        fields = ['id', 'study_subject_id', 'subject_device_id', 'is_valid'] 


class UpdateSubjectDeviceStudySerializer(serializers.ModelSerializer):

    class Meta:
        model = SubjectDeviceStudy
        fields = ['is_valid'] 


                

