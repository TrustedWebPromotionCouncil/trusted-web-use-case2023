from django.apps import AppConfig


class CrodirectoryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'crodirectory'
