from django.urls import path
from . import views

urlpatterns = [
    path('participant/<participant_id>/', views.ParticipantView.as_view()),
    path('studies/<participant_id>/', views.studies),
    path('allstudies/', views.all_studies_by_participant),
    path('studyparticipant/', views.StudyParticipantView.as_view()),
    path('studyparticipant/<id>/', views.StudyParticipantView.as_view()),

    path('contacts/<participant_id>/<study_id>/<hospital_id>/', views.contacts),
    path('createsubject/<subject_code>/<study_id>/<hospital_id>/', views.createsubject),  
    path('subject/<studysubjects_id>/', views.SubjectView.as_view()),
    path('changesubjectstatus/<studysubjects_id>/', views.changesubjectstatus),
    path('subjectaccept/<studysubjects_id>/', views.subjectaccept),
    path('icdocument/<study_id>/<hospital_id>/', views.IcDocumentView.as_view()),
    path('createexplainsigner/', views.ExplainSignerView.as_view()),
    path('deleteexplainsigner/<study_subject_ic_id>/', views.ExplainSignerView.as_view()), 
    path('signofexplain/<study_subject_ic_id>/', views.SignOfExplainView.as_view()),     

    path('subjectfirstaccess/<studysubjects_id>/', views.subjectfirstaccess),           
    path('updatesubjecturi/<studysubjects_id>/', views.UpdateSubjectUriView.as_view()),  
    path('subjectcontacts/<studysubjects_id>/', views.subjectcontacts),                  
    path('subjectstudyhospitals/<studysubjects_id>/', views.subjectstudyhospital),       
    path('subjecticdoc/<studysubjects_id>/', views.subjecticdoc),                        
    path('createsubjectic/', views.CreateStudySubjectIcView.as_view()),                 
    path('withdrawic/', views.CreateWithdrawIc.as_view()),                              
    path('aftericdoc/<studysubjects_id>/', views.aftericdoc),                           
    path('iclogs/<studysubjects_id>/', views.iclogs),                                    
    path('subjectstatus/<studysubjects_id>/', views.StudySubjectsStatusView.as_view()), 
    path('updatesubjectdevice/', views.SubjectDeviceView.as_view()),                            
    path('subjectdevicestudy/<studysubjects_id>/', views.SubjectDeviceStudyView.as_view()),      
    path('devicecontacts/<subject_device_id>/', views.devicecontacts),

]