from django.contrib import admin
from django.db.models import Count

from . import models
from .models import Study, Hospital, StudyHospital, Participant, StudySubjects, StudySubjectIc


@admin.register(models.Hospital)
class HospitalAdmin(admin.ModelAdmin):
    list_display = ['name', 'address', 'dcf_code', 'description', 'is_valid', 'created', 'updated']
    list_per_page = 10
    list_filter = ['is_valid']
    ordering = ['name']
    search_fields = ['name__istartswith', 'dcf_code']


@admin.register(models.Participant)
class ParticipantAdmin(admin.ModelAdmin):
    list_display = ['name', 'sub_name', 'email', 'role', 'participant_id', 'description', 'uri', 'is_valid', 'created', 'updated']
    list_filter = ['role', 'is_valid', 'updated']
    list_per_page = 10
    ordering = ['name', 'sub_name']
    search_fields = ['name__istartswith', 'sub_name__istartswith', 'email']


@admin.register(models.Study)
class StudyAdmin(admin.ModelAdmin):
    list_display = ['name', 'description', 'is_valid', 'created', 'updated']
    list_per_page = 10
    list_filter = ['is_valid']
    ordering = ['name']
    search_fields = ['name']


class StudyHospitalParticipant(admin.TabularInline):
    autocomplete_fields = ['participant']
    min_num = 0
    max_num = 10
    model = models.StudyParticipants
    extra = 0


@admin.register(models.StudyHospital)
class StudyHospitalAdmin(admin.ModelAdmin):
    autocomplete_fields = ['study', 'hospital']
    inlines = [StudyHospitalParticipant]
    list_display = ['study', 'hospital', 'dcf_code', 'box_id', 'description', 'is_valid', 'created', 'updated']
    list_filter = ['is_valid']
    list_per_page = 10

    search_fields = ['study__name', 'hospital__name', 'hospital__dcf_code']

    def dcf_code(self, study_hospital):
        hospital = Hospital.objects.filter(id=study_hospital.hospital.id).first()

        return hospital.dcf_code


@admin.register(models.StudyParticipants)
class StudyParticipantsAdmin(admin.ModelAdmin):
    autocomplete_fields = ['study_hospital', 'participant']
    list_display = ['study', 'hospital', 'participant', 'role', 'description', 'is_valid', 'created', 'updated']
    list_filter = ['is_valid']
    list_per_page = 10

    ordering = ['study_hospital', 'participant']
    search_fields = ['study_hospital__study__name', 'study_hospital__hospital__name', 'participant__name', 'participant__sub_name']

@admin.register(models.StudySubjects)
class StudySubjectsAdmin(admin.ModelAdmin):
    autocomplete_fields = ['study', 'hospital']
    list_display = ['id', 'subject_code', 'study', 'hospital', 'role', 'description', 'uri', 'first_access', 'accepted' , 'box_id_subject','created', 'updated']
    list_filter = [  'updated']
    list_per_page = 10
    ordering = ['subject_code']
    search_fields = ['subject_code__istartswith']

@admin.register(models.StudySubjectsStatus)
class StudySubjectsStatusAdmin(admin.ModelAdmin):
    autocomplete_fields = ['study_subject']
    list_display = [ 'study_subject', 'status', 'created', 'updated']

    list_filter = [ 'status', 'updated']
    list_per_page = 10
    ordering = ['study_subject']
    search_fields = ['study_subject__istartswith']


@admin.register(models.SubjectDevices)
class SubjectDevicesAdmin(admin.ModelAdmin):
    
    list_display = [  'id', 'sequence_id', 'device_uri',  'created', 'updated', 'device_master_id']
    
    list_filter = [ 'device_master_id', 'created', 'updated']
    list_per_page = 10
    ordering = ['device_master_id']


@admin.register(models.SubjectDeviceStudy)
class SubjectDeviceStudyAdmin(admin.ModelAdmin):
    autocomplete_fields = ['study_subject']
    list_display = [  'study_subject', 'subject_device',   'created', 'updated', 'is_valid']
    
    list_filter = [ 'study_subject', 'updated']
    list_per_page = 10
    ordering = ['study_subject']
    search_fields = ['study_subject__istartswith']

@admin.register(models.IcDocument)
class IcDocumentAdmin(admin.ModelAdmin):
    autocomplete_fields = ['study_hospital']
    list_display = [  'study_hospital', 'ic_doc_seq',  'ic_doc_name', 'ic_doc_box_id', 'created', 'updated']
        
    list_filter = [ 'study_hospital', 'updated']
    list_per_page = 10
    ordering = ['study_hospital']
    search_fields = ['study_hospital__istartswith', 'ic_doc_name__isstartswith']


@admin.register(models.StudySubjectIc)
class StudySubjectIcAdmin(admin.ModelAdmin):
    autocomplete_fields = ['study_subject']
    list_display = [  'study_subject', 'ic_number',  'ic_number_seq', 'ic_type','ic_doc', 'esign_status','esign_signer_id','esign_date','ic_signdoc_nm','ic_signdoc_box_id','withdraw_reason', 'created', 'updated']
        
    list_filter = [ 'study_subject', 'updated']
    list_per_page = 10
    ordering = ['study_subject']
    search_fields = ['study_subject__istartswith']



