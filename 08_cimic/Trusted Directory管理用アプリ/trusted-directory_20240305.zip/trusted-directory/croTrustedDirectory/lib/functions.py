from django.utils.dateparse import parse_date, parse_datetime


def _parse_from_strdate_to_datatime_tz_jp(strdate, end_of_day = False):
    '''
    社内用：
        ・date のみの string (yyyy-mm-ddなど) を datetime 型に変換する。
        ・timezone がJPであることを明示した datetime を返す。
        ・end_of_dayがTrueなら時刻は23時59分59.999999秒、Falseなら00.00.00
    '''
    try:
        if end_of_day:
            return parse_datetime(strdate + str(' 23:59:59.999999+09:00'))
        else:
            return parse_datetime(strdate + str(' 00:00:00.000000+09:00'))

    except Exception as e:
        raise e
