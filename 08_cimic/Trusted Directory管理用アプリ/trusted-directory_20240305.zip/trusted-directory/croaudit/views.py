import http
from django.shortcuts import get_object_or_404

from django.utils.dateparse import parse_date, parse_datetime
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import api_view

from croTrustedDirectory.lib.functions import _parse_from_strdate_to_datatime_tz_jp

from croaudit.models import AuditLog
from croaudit.serializers import AuditLogSerializer
from crodirectory.models import Participant, StudyHospital, StudySubjects

import logging

class Audit(APIView):
    '''
    PCアプリ用
    '''
    def get(self, request, date_from, date_to):

        date_from = _parse_from_strdate_to_datatime_tz_jp(date_from)
        date_to = _parse_from_strdate_to_datatime_tz_jp(date_to, end_of_day=True)

        print('date_of_action__gte: {}'.format(date_from))
        print('date_of_action__lte: {}'.format(date_to))

        audit_log = AuditLog \
            .objects \
            .filter(date_of_action__gte=date_from) \
            .filter(date_of_action__lte=date_to) \
            .all()

        if (audit_log.count() > 0):
            serializer = AuditLogSerializer(audit_log, many=True)
            return Response(serializer.data)

        return Response(status=http.HTTPStatus.NOT_FOUND)

    def post(self, request):

        data = request.data
        participant_id = data.get('participant_id')
        action_user_id = get_object_or_404(Participant, participant_id=participant_id, is_valid=True).id
        data['action_user_id']=str(action_user_id)
        del data['participant_id']
 
        try:
            serializer = AuditLogSerializer(data=request.data)
            print('request.data: ' + str(request.data))

            if serializer.is_valid():
                serializer.save()
                return Response('ok')
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as ex:
            return Response(str(ex), status=status.HTTP_400_BAD_REQUEST)


class SubjectAudit(APIView):
    '''
    スマホアプリ用
    '''
    def get(self, request, studysubject_id, date_from, date_to):

        date_from = _parse_from_strdate_to_datatime_tz_jp(date_from)
        date_to = _parse_from_strdate_to_datatime_tz_jp(date_to, end_of_day=True)

        print('date_of_action__gte: {}'.format(date_from))
        print('date_of_action__lte: {}'.format(date_to))

        audit_log = AuditLog \
            .objects \
            .filter(study_subject_id = studysubject_id) \
            .filter(date_of_action__gte=date_from) \
            .filter(date_of_action__lte=date_to) \
            .all()

        if (audit_log.count() > 0):
            serializer = AuditLogSerializer(audit_log, many=True)
            return Response(serializer.data)

        return Response([])


    def post(self, request):

        data = request.data
        try:
            study_subject = StudySubjects.objects.get(pk = data.get('study_subject_id'))
            study_id = study_subject.study_id
            hospital_id = study_subject.hospital_id
            subject_code = study_subject.subject_code

            data['study_hospital_id'] = StudyHospital.objects.get(study_id =study_id, hospital_id = hospital_id).id
            data['action_user_id'] = str(study_id) + '-' + subject_code

            try:
                serializer = AuditLogSerializer(data=data)
                print('data: ' + str(data))
                print(serializer)

                if serializer.is_valid():
                    serializer.save()
                    return Response({'result': 'True'})
                else:
                    logging.error(str(serializer.errors))
                    return Response({'result': 'False'})
            except Exception as ex:
                logging.error(str(ex))
                return Response({'result': 'False'})    
            
        except Exception as ex:
            logging.error(str(ex))
            return Response({'result': 'False'})

