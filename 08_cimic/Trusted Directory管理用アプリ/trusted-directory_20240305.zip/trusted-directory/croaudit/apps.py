from django.apps import AppConfig


class CroauditConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'croaudit'
