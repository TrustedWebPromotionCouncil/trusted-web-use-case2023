from django.urls import path
from . import views

urlpatterns = [
    path('auditlog/<date_from>/<date_to>/', views.Audit.as_view()),
    path('auditlogwrite/', views.Audit.as_view()),

    path('subjectauditlog/<studysubject_id>/<date_from>/<date_to>/', views.SubjectAudit.as_view()),
    path('subjectauditlogwrite/', views.SubjectAudit.as_view()),
]