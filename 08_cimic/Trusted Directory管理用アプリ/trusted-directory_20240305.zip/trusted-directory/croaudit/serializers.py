import hashlib

from rest_framework import serializers

from crodirectory.models import StudySubjects

from .models import AuditLog


class AuditLogSerializer(serializers.ModelSerializer):
    study_subject_id = serializers.PrimaryKeyRelatedField(queryset=StudySubjects.objects.all(), source='study_subject', allow_null=True)

    class Meta:
        model = AuditLog
        fields = ['name',
                  'sub_name',
                  'action_user_id',
                  'action',
                  'contact_list',
                  'file_name',
                  'study_hospital_id',
                  'hash',
                  'study_subject_id',
                  'date_of_action']

    def get_hash(self, data):
        sha = hashlib.sha256()
        sha.update(data.encode())
        return sha.hexdigest()

    def create(self, validated_data):
        audit_log = AuditLog(**validated_data)

        print("Saving audit log entry: " + str(validated_data))

        prevHash = ""
        myHash = self.get_hash(str(validated_data))
        print("myhash:")
        print(myHash)

        if AuditLog.objects.count() > 0:
            prevHash = AuditLog.objects.last().hash

        print("prevHash:")
        print(prevHash)

        hashToSave = myHash.join(prevHash)
        audit_log.hash = self.get_hash(hashToSave)
        audit_log.save()

        return audit_log

