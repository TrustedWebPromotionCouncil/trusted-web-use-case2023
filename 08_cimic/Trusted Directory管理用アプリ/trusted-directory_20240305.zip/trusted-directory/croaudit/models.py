from django.db import models

from crodirectory.models import StudySubjects

class AuditLog(models.Model):
    ACTION_CHOICES = [
        ('SignedAndEncrypted', 'SignedAndEncrypted'),
        ('DecryptedAndVerified', 'DecryptedAndVerified')
    ]
    action_user_id = models.CharField(max_length=20, default="")
    study_hospital_id = models.IntegerField()
    name = models.CharField(max_length=255)
    sub_name = models.CharField(max_length=255, null=True, blank=True)
    file_name = models.CharField(max_length=255)
    contact_list = models.TextField(max_length=2000)
    action = models.CharField(max_length=2000, choices=ACTION_CHOICES, default="E")
    date_of_action = models.DateTimeField(auto_now_add=True)
    hash = models.CharField(max_length=64, null=True, blank=True)
    study_subject = models.ForeignKey(StudySubjects, on_delete=models.PROTECT, related_name='audit_log', null=True)

    class Meta:
        indexes = [
            models.Index(fields=['action_user_id']),
            models.Index(fields=['name', 'sub_name']),
            models.Index(fields=['study_hospital_id']),
        ]
