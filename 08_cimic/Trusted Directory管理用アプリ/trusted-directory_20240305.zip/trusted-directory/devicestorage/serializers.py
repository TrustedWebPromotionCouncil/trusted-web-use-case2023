from rest_framework import serializers
from rest_framework.validators import UniqueTogetherValidator

from crodirectory.models import SubjectDevices

from .models import DeviceActivity, DeviceData, Devices

class DeviceDataSerializer(serializers.ModelSerializer):
    activity_id = serializers.PrimaryKeyRelatedField(queryset=DeviceActivity.objects.all(), source='activity')
    subject_device_id = serializers.PrimaryKeyRelatedField(queryset=SubjectDevices.objects.all(), source='subject_device')
    collected_date = serializers.DateField(required = True)
    encrypted_data = serializers.CharField(required = True)

    class Meta:
        model = DeviceData
        fields = [
            'subject_device_id',
                  'activity_id',
                  'collected_date',
                  'encrypted_data']




class CreateOrUpdateDeviceDataSerializer(serializers.Serializer):
    subject_code = serializers.CharField()  
    study_id = serializers.IntegerField()
    device_activity_id = serializers.IntegerField()
    collected_date = serializers.DateTimeField()
    encrypted_data = serializers.CharField()


class DeviceActivitySerializer(serializers.ModelSerializer):
       
    class Meta:
        model = DeviceActivity
        fields = ['id',
                  'device_id',
                  'activity_name']
        


class DevicesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Devices
        fields = ['id',
                  'device_name']
