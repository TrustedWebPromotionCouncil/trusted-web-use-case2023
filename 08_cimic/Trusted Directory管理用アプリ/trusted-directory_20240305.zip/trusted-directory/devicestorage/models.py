from datetime import timezone
import random
import string

from django.db import models
from django.utils.crypto import get_random_string
from crodirectory.models import StudySubjects, SubjectDevices

# Create your models here.

class Devices(models.Model):
    device_name = models.CharField(max_length=100) 
    is_valid = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.device_name
    
class DeviceActivity(models.Model):
    device = models.ForeignKey(Devices, on_delete=models.PROTECT, related_name='device')
    activity_name = models.CharField(max_length=100) 
    is_valid = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.device.device_name +  '-'+self.activity_name

class DeviceData(models.Model):
    subject_device = models.ForeignKey(SubjectDevices, on_delete=models.PROTECT)  
    activity = models.ForeignKey(DeviceActivity, on_delete=models.PROTECT)  
    collected_date = models.DateField( null=True, blank=True)
    encrypted_data = models.TextField( null=True, blank=True)
    is_valid = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return str(self.subject_device) +  '-'+self.activity.activity_name




