from django.shortcuts import get_object_or_404, get_list_or_404
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.views import APIView

from django.utils.dateparse import parse_date

from croTrustedDirectory.lib.functions import _parse_from_strdate_to_datatime_tz_jp

from .models import DeviceData, DeviceActivity, Devices, SubjectDevices
from crodirectory.models import StudySubjects, SubjectDeviceStudy
from .serializers import DeviceDataSerializer, CreateOrUpdateDeviceDataSerializer, DeviceActivitySerializer, DevicesSerializer

class DeviceDataView(APIView):
    def get(self, request, study_subject_id, activity_id, date_from, date_to):

        subject_device_studies = SubjectDeviceStudy.objects.filter(study_subject_id=study_subject_id)

        subject_device_ids = subject_device_studies.values_list('subject_device_id', flat=True).distinct()

        date_from = _parse_from_strdate_to_datatime_tz_jp(date_from)
        date_to = _parse_from_strdate_to_datatime_tz_jp(date_to, end_of_day=True)

        print('collected_date__gte: {}'.format(date_from))
        print('collected_date__lte: {}'.format(date_to))

        for id in subject_device_ids:
            print(id)

    
        device_data = DeviceData \
            .objects \
            .filter(subject_device_id__in=subject_device_ids) \
            .filter(activity_id = activity_id) \
            .filter(collected_date__gte=date_from) \
            .filter(collected_date__lte=date_to) \
            .all()
        print(device_data)

        if (device_data.count() > 0):
            serializer = DeviceDataSerializer(device_data, many=True)
            return Response(serializer.data)

        return Response([])
    

    def post(self, request):
        
        serializer = DeviceDataSerializer(data=request.data)
        print('request.data: ' + str(request.data))

        if serializer.is_valid():
            validated_data = serializer.validated_data

            try:
                device_data = DeviceData.objects.get( \
                    subject_device=validated_data["subject_device"], \
                    activity = validated_data["activity"], \
                    collected_date = validated_data["collected_date"])


                try:
                    serializer.update(device_data, validated_data)

                    return Response({"result": "True"})

                except Exception as e:
                    print(e)
                    return Response({"result": "False"})
                    
            except:
                try:
                    serializer.create(validated_data)
                    print("create")
                    return Response({"result": "True"})
                except Exception as e:
                    print(e)
                    return Response({"result": "False"})

        else:
            print(serializer.errors)
            return Response({"result": "False"})


        
    
class DeviceMasterView(APIView):
    def get(self, request):
        devices = Devices.objects.filter(is_valid=True)
        activities = DeviceActivity.objects.filter(is_valid=True)

        devices_serializer  = DevicesSerializer(devices,  many=True)
        activities_serializer  = DeviceActivitySerializer(activities,  many=True)

        response_data  = {
            'devices': devices_serializer.data,
            'activities': activities_serializer.data
        }
        return Response(response_data)
    


    