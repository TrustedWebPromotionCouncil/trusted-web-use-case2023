from django.contrib import admin
from django.db.models import Count

from . import models


@admin.register(models.Devices)
class DevicesAdmin(admin.ModelAdmin):
    list_display = [  'id', 'device_name',  'is_valid',  'created', 'updated']
        
    list_filter = [ 'updated']
    list_per_page = 10
    search_fields = ['device_name__istartswith']

@admin.register(models.DeviceActivity)
class DeviceActivityAdmin(admin.ModelAdmin):
    list_display = [  'id', 'device', 'activity_name', 'is_valid',  'created', 'updated']
        
    list_filter = [ 'device','updated']
    list_per_page = 10
    search_fields = ['device_name__istartswith', 'activity_name__istartswith']

@admin.register(models.DeviceData)
class DeviceDataAdmin(admin.ModelAdmin):
    list_display = [  'id', 'subject_device', 'activity', 'collected_date', 'encrypted_data',   'is_valid',  'created', 'updated']
        
    list_filter = [ 'subject_device','collected_date', 'activity']
    list_per_page = 10


