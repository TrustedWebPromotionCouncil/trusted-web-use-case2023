from django.urls import path
from . import views

urlpatterns = [
    path('devicedata/<study_subject_id>/<activity_id>/<date_from>/<date_to>/', views.DeviceDataView.as_view()),
    path('postdevicedata/', views.DeviceDataView.as_view()),
    path('devicemaster/', views.DeviceMasterView.as_view()),
    

]